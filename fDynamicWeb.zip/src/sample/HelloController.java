package sample;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller //해당 클래스가 스프링 MVC의 컨트롤러를 구현한 클래스라는 것을 지정한다.
public class HelloController {

	@RequestMapping("/start.do")//start.do라는 불려져왔을때 이 함수가 불려졌으면 좋겠다
	//클라이언트의 요청을 처리할 메서드를 지정한다
	public ModelAndView test() {
		System.out.println("start.do 요청됨");
		
		ModelAndView mv = new ModelAndView();
		//mv.setViewName("/WEB-INF/view/hello.jsp");//밑에 값들을 이 페이지에 넘기려고 합니다
		mv.setViewName("hello");//이름만 쓰면 앞뒤에 알아서 따라 붙으려면 common-servlet에 설정해줘야한다
		mv.addObject("name","홍길동");
		mv.addObject("message", "오늘은 뭐먹징?");
		//해당하는 view페이지를 파일을 지정하여 사용자가 함부로 사용하지 못하게 mvc패턴을 사용
		return mv;
	}
}
